<template>
  <div id="app" class="container-fluid">
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #e9b3ff;">
      <div class="container-fluid">
        <a class="navbar-brand fw-bold fs-2 text-dark" href="#">My Profile Page</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link fw-bold fs-5 text-dark" href="#profile">Profil</a>
            </li>
            <li class="nav-item">
              <a class="nav-link fw-bold fs-5 text-dark" href="#education">Pendidikan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link fw-bold fs-5 text-dark" href="#experience">Pengalaman</a>
            </li>
            <li class="nav-item">
              <a class="nav-link fw-bold fs-5 text-dark" href="#skills">Keterampilan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link fw-bold fs-5 text-dark" href="#contact">Kontak</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <section id="profile" class="profile-section row mb-4">
      <div class="col-md-8">
        <div class="profile-info">
          <h2>Fithrotul Muhclisiyah</h2>
          <p class="fw-bold text-dark">Mahasiswa | Universitas Brawijaya | Teknologi Informasi</p>
          <p>
            Halo! Saya Fithrotul Muhclisiyah, seorang mahasiswa jurusan Teknologi Informasi di Universitas Brawijaya angkatan 2023. Saya tertarik di bidang teknologi, maka dari itu saya memasuki jurusan ini, selain itu saya memiliki ketertarikan dalam desain antarmuka dan ingin belajar serta mendalami mengenai UI design.
          </p>
        </div>
      </div>
      <div class="col-md-4 profile-photo">
        <div class="card text-center">
          <div class="card-body">
            <img src= '.\assets\profil.png' class="img-fluid" />
          </div>
        </div>
      </div>
    </section>

    <!-- Education Section -->
    <section id="education" class="education-section row mb-4">
      <div class="col-md-12">
        <h3>Pendidikan</h3>
        <p>SMP NEGERI 1 BANGIL (2017-2020)</p>
        <p>SMA NEGERI 1 BANGIL (2020-2023)</p>
        <p>Universitas Brawijaya (2023-sekarang)</p>
      </div>
    </section>

    <!-- Experience Section -->
    <section id="experience" class="experience-section mb-4">
  <h3>Pengalaman</h3>
  <div class="experience-grid">
    <div class="experience-item">
      <strong>Membuat website laundry.</strong>
    </div>
    <div class="experience-item">
      <strong>UI/UX Laundry.</strong>
    </div>
    <div class="experience-item">
      <strong>Praktik Algoritma dan Pemrograman:</strong> Membuat Program Kasir menggunakan C++
    </div>
    <div class="experience-item">
      <strong>Praktik Basis Data:</strong> Membuat ERD (Entity Relationship Diagram) dan Database Supermarket
    </div>
    <div class="experience-item">
      <strong>Praktik Pemrograman Berorientasi Objek:</strong> Membuat Aplikasi Rental Mobil menggunakan NetBeans
    </div>
    <div class="experience-item">
      <strong>Praktik UI/UX:</strong> Mendesain Aplikasi Belajar Matematika menggunakan Figma
    </div>
  </div>
</section>


    <!-- Skills Section -->
    <section id="skills" class="skills-section row mb-4">
      <div class="col-md-12">
        <h3>Keterampilan</h3>
        <div class="skills-container">
          <img src="./assets/php.png" alt="PHP" />
          <img src="./assets/figma.png" alt="Figma" />
          <img src="./assets/python.png" alt="Python" />
          <img src="./assets/mysql.png" alt="MySQL" />
          <img src="./assets/c++.png" alt="C++" />
          <img src="./assets/dart.png" alt="Dart" />
          <img src="./assets/html.png" alt="HTML" />
        </div>
      </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact-section row mb-4">
      <div class="col-md-12">
        <h3 class="text-center">Kontak</h3>
        <form class="contact-form">
          <div class="form-group mb-3">
            <label for="name">Nama</label>
            <input type="text" id="name" class="form-control" placeholder="Nama Anda" />
          </div>
          <div class="form-group mb-3">
            <label for="email">Email</label>
            <input type="email" id="email" class="form-control" placeholder="Email Anda" />
          </div>
          <div class="form-group mb-3">
            <label for="message">Pesan</label>
            <textarea id="message" class="form-control" rows="4" placeholder="Pesan Anda"></textarea>
          </div>
          <div class="text-center">
            <button type="submit" class="btn btn-primary">Kirim</button>
          </div>
        </form>
      </div>
    </section>

    <footer class="text-center">
      <p>&copy; 2024 Fithrotul Muhclisiyah. All Rights Reserved.</p>
    </footer>
  </div>
</template>

<script>
import profileImage from './assets/profil.png'; // Import the image at the top

export default {
  name: 'Home',
  data() {
    return {
      profile: {
        image: null,
      },
    };
  },
  methods: {
    onFileChange(event) {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          this.profile.image = e.target.result;
        };
        reader.readAsDataURL(file);
      } else {
        alert("File tidak valid!");
      }
    },
  },
};
</script>

<style>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

html, body {
  height: 100%; 
  font-family: 'Arial', sans-serif;
  background-color: #f4f4f4;
  color: #333;
}

#app {
  min-height: 100vh;
  padding: 20px;
  background-color: #ffffff;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.skills-section {
  padding: 20px;
  background-color: #f8f9fa; /* Light background color */
  border-radius: 8px; /* Rounded corners */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Soft shadow */
}

.skills-container {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
}

.skills-container img {
  max-width: 80px; /* Set max width for logos */
  height: auto; /* Maintain aspect ratio */
  margin: 10px; /* Spacing between logos */
  transition: transform 0.3s; /* Smooth hover effect */
}

.skills-container img:hover {
  transform: scale(1.1); /* Scale up on hover */
}

h3, h2 {
  text-align: center;
  padding-bottom: 10px;
}

.experience-section {
  padding: 20px;
  background-color: ##e9b3ff; /* White background */
  border-radius: 8px; /* Rounded corners */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Soft shadow */
}

.experience-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); /* 3 kolom */
  gap: 20px; /* Spacing between items */
}

.experience-item {
  background-color: #e9b3ff; /* Light gray background */
  padding: 15px; /* Space inside each item */
  border-radius: 8px; /* Rounded corners for each item */
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Slight shadow */
  transition: transform 0.3s; /* Smooth hover effect */
}

.experience-item:hover {
  transform: translateY(-5px); /* Move up slightly on hover */
}


.profile-section {
  padding: 20px;
  background-color: #ffffff; /* Warna latar belakang ungu */
  border-radius: 8px; /* Sudut membulat */
  box-shadow: none; /* Menghilangkan bayangan */
}

.profile-photo {
  display: flex; /* Mengatur flexbox untuk penempatan */
  justify-content: center; /* Menempatkan foto di tengah */
  align-items: center; /* Menempatkan foto secara vertikal di tengah */
  padding: 20px; /* Spasi di sekitar foto */
}

.profile-photo img {
  max-width: 150px; /* Lebar maksimum untuk gambar */
  height: auto; /* Mempertahankan rasio aspek */
  border-radius: 50%; /* Membuat gambar berbentuk lingkaran */
  border: 3px solid #e9b3ff; /* Garis tepi hijau tua untuk gambar */
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3); /* Bayangan pada gambar */
}


.contact-form {
  max-width: 600px;
  margin: 0 auto;
}

.contact-form .form-group {
  margin-bottom: 1rem;
}

.contact-form .btn {
  transition: background-color 0.3s ease;
}

.contact-form .btn:hover {
  background-color: #e9b3ff;
}

footer {
  margin-top: 20px;
  padding: 10px;
  background-color: #e9b3ff;
  color: #000000;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

p{
  text-align: center;
}

.experience-item {
  background-color: #e9b3ff; /* Darker aqua for experience items */
  padding: 10px; /* Mengurangi ruang dalam setiap item */
  border-radius: 8px; /* Rounded corners for each item */
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Slight shadow */
  transition: transform 0.3s; /* Smooth hover effect */
  font-size: 0.9em; /* Mengurangi ukuran font */
  text-align: center; /* Mengatur teks agar berada di tengah */
}

.education-section {
  padding: 20px;
  background-color: #ffffff; /* Warna latar belakang putih */
  border-radius: 8px; /* Sudut membulat */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Bayangan lembut */
}

.education-section h3 {
  font-size: 24px; /* Ukuran font untuk judul */
  color: #000000; /* Warna hijau tua untuk judul */
  text-align: center; /* Menempatkan judul di tengah */
  margin-bottom: 15px; /* Spasi di bawah judul */
}

.education-section p {
  font-size: 18px; /* Ukuran font untuk deskripsi */
  color: #333; /* Warna gelap untuk teks */
  margin: 5px 0; /* Spasi vertikal di antara paragraf */
  text-align: center; /* Menempatkan teks di tengah */
}

</style>