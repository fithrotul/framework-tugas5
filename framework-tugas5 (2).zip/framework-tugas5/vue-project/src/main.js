import { createApp } from 'vue';
import App from './Home.vue'; // Mengimpor komponen utama
import 'bootstrap/dist/css/bootstrap.min.css'; // Mengimpor CSS Bootstrap
import 'bootstrap/dist/js/bootstrap.bundle.min.js'; // Mengimpor JavaScript Bootstrap

const app = createApp(App);
app.mount('#app'); // Menggunakan app untuk mount ke elemen dengan ID 'app'
